trajectory_gui_log = """
Welcom to Mars Lander challenge !

Here are some usefull commands :
 - RIGHT ARROW : evolve your population
 - SPACE : continue the evolution even if a good trajectory has been found
 - Q : Quit the simulation
"""

manual_gui_log = """
Welcom to Mars Lander challenge !

Here are some usefull commands :
 - RIGHT ARROW : turn clockwise
 - LEFT ARROW : turn anti-clockwise
 - UP ARROW : power up by one
 - DOWN ARROW : power down by one
 - Q : Quit the simulation
"""
