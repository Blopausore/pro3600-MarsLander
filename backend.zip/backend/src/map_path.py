FLAT_SURFACE = "flat_surface.json"
LEVEL_ONE = "level_one_cg.json"
CAVE_REVERSED = "cave_reversed.json"