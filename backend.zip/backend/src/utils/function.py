from numpy import exp


"""Sigmoid function
Have been used on some test on score calculation, ...
"""
sigmoid = lambda x: 1/(1 + exp(-x))

